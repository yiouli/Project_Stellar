How to start Server

Content in current Directory:
bin, lib, testInput, run.cmd, run, readme.txt

First make sure you have JDK (NOT JRE) at least 1.6 installed.

For Windows:
Run cmd, cd to current directory then enter "run" in cmd.

For Linux based:
Open terminal, cd to current directory, then "sh run"
